import { Product } from './../product.model';
import { Router } from '@angular/router';
import { ProductService } from './../product.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {

  product: Product = {
    nome: "",
    valor: null,
    quantidade: null
  }
  constructor(
    private productServise: ProductService,
    private router: Router
    ) { }

  ngOnInit(): void {
  }

  createProduct(){
    this.productServise.create(this.product).subscribe(() =>{
      this.productServise.showMessage("Salvo com sucesso");
      this.router.navigate(["/products"]);
    });
  }

  cancel(){
    this.router.navigate(["/products"]);
  }

}
