export interface Product{
    id?: number;
    nome: string;
    quantidade: number;
    valor: number;
}