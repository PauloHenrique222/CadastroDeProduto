import { Injectable } from '@angular/core';
import { HeaderData } from './header-data.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  private headerData = new BehaviorSubject<HeaderData>({
    title: 'Inicío',
    icon: 'home',
    routeUrl: ''
  })

  constructor() { }

  get headerDate(): HeaderData{
    return this.headerData.value;
  }

  set headerDate(headerData: HeaderData){
    this.headerData.next(headerData);
  }
}
